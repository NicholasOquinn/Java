import java.util.Random;

public class Random_Sentences {

    // 4 different arrays of words to create sentences from.
    private static final String[] articles = {"the", "a", "one", "some", "any"};
    private static final String[] nouns = {"boy", "girl", "dog", "town", "car"};
    private static final String[] verbs = {"drove", "jumped", "ran", "walked", "skipped"};
    private static final String[] prepositions = {"to", "from", "over", "under", "on"};

    public static void main(String[] args) {
        //create a new Random object
        Random rand = new Random();

        // int variable to hold upperbound limit when generating random numbers
        int upperbound = 5;

        //initialize counter to 0.
        int counter = 0;

        // while loop to create 20 different sentences.
        while (counter < 20) {
            // Create String Array to store randomly generated words, spaces, and ending period.
            String[] random_sentence_array = {articles[rand.nextInt(upperbound)], " ", nouns[rand.nextInt(upperbound)],
                    " ", verbs[rand.nextInt(upperbound)], " ", prepositions[rand.nextInt(upperbound)], " ",
                    articles[rand.nextInt(upperbound)], " ", nouns[rand.nextInt(upperbound)], "."};

            // isolate first letter and remaining letters, uppercase first letter, concatenate both back together,
            // and replace first string in the array with it.
            String first_letter = random_sentence_array[0].substring(0, 1);
            String remaining_lettters = random_sentence_array[0].substring(1);
            first_letter = first_letter.toUpperCase();
            random_sentence_array[0] = first_letter + remaining_lettters;

            // Create string buffer object to convert String Array to String.
            StringBuffer sb = new StringBuffer();
            for(int i = 0; i < random_sentence_array.length; i++) {
                sb.append(random_sentence_array[i]);
            }
            String str = sb.toString();
            // Print the sentences.
            System.out.println(str);

            /*for (String word : random_sentence_array) {

                System.out.print(word);
            }*/
            // advance the counter.
            counter++;
        }
    }
}
