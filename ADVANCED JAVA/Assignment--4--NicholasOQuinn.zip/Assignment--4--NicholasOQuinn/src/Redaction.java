import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Formatter;

public class Redaction {
    public static void main(String[] args) {
        // Try block for dangerous code
        try {

            // Create a new File, Scanner, and Formatter object.
            File myObj = new File("sampleInfo.txt");
            Scanner myReader = new Scanner(myObj);
            Formatter output;
            output = new Formatter("sampleInfoRedacted.txt");

            // Iterate through the text file
            while (myReader.hasNextLine()) {

                //Store each line in a String variable and replace any numerical digits they may contain using regex
                String data = myReader.nextLine();
                data = data.replaceAll("\\d", "#");

                //Write the formatted lines to the text file and print them to the console.
                output.format("%s%n%n", data);
                System.out.println(data);
            }

            // Close the formatter
            output.close();

        // Catch block for handling exceptions.
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
