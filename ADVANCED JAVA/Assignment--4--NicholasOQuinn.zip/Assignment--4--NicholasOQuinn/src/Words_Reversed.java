import java.util.Scanner;

public class Words_Reversed {
    public static void main(String[] args) {

        //Ask for a sentence to reverse
        System.out.print("Enter a sentence to reverse: ");
        Scanner input = new Scanner(System.in);
        String sentence = input.nextLine();
        String reverse = "";

        // tokenize the sentence using a space as delimiter
        String[] tokenized_sentence = sentence.split("\\s+");

        // Reverse the string by looping backwards through the tokenized sentence.
        for (int i = tokenized_sentence.length; i > 0; i--) {
            reverse += tokenized_sentence[i - 1] + " ";
        }

        // Print the reversed sentence.
        System.out.println(reverse);
    }
}
