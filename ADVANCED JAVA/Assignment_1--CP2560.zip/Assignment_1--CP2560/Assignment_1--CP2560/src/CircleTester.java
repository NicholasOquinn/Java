public class CircleTester {
    public static void main(String[] args) {
        Circle circle = new Circle(5);
        System.out.println(circle.getDescription());
    }
}
