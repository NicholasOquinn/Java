public abstract class Shape {

    public abstract double Area();

    public abstract String getDescription();
}
